"use client";
import { use } from "react";
import { DocDetail } from "@/components/sb/Docs";
export default function Page({ params }: { params: Promise<{ id: string }> }) { const { id } = use(params); return <DocDetail kind="sale" id={id} />; }
